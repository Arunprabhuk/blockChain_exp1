import React, { useState } from 'react';

import { useDispatch } from 'react-redux';
import { addProduct } from '../redux/Slice'; 

const ProductInput = () => {
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
 
   const dispatch = useDispatch();
   let currentID = 4;

   const getNextSequentialID = () => {
   const nextID = currentID;
    currentID += 1; 
    return nextID;
  };

  const handleAddProduct = () => {
   
    const newID = getNextSequentialID();
   
    const newProduct = {
      id: newID,
      name: productName,
      price: parseFloat(price),
  
    };
console.log(newProduct);
    // Dispatch the addProduct action
    dispatch(addProduct(newProduct));

   
    setProductName('');
    setPrice('');
    
  };
  const [showAddtable, setShowAddtable] = useState(false);
  
    return (
    <>
    <button type="button" class="btn inputbtn "onClick={() => setShowAddtable(true)}>Add+</button>
    {showAddtable && (
      <div className="row">
        <div className=" col-md-8">
          <div className=" inputcard card">
            <div className="card-body">
              <h2 className="card-title">Add Product</h2>
              <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product Name"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                />
              </div>
              <div className="mb-3">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Price"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </div>
              {/* <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                />
              </div> */}
              <button className="btn btn-primary" onClick={handleAddProduct}>
                Add
              </button>
            </div>
          </div>
        </div>
        </div>
        
        
    )}
        </>
      );
    };
    
export default ProductInput;